(function($) {
	$(document).ready(function() {
		// let homeVideoSection = document.querySelector('#home-video-section');
		// let homeVideo = homeVideoSection.querySelector('video');
		
		// let heroDecorObserver = new IntersectionObserver((entryList, observer) => {
			
		// }); 		
		
	})
})(jQuery);